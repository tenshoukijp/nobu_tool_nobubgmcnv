#include "AbstractSink.h"

CAbstractSink::CAbstractSink(void)
{
}


CAbstractSink::~CAbstractSink(void)
{
}
