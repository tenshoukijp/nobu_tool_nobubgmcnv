#pragma once

int Ktsl2asbinToKvs(char *szVpsFileName);