#pragma once

int OggToWav(char *szOggFileName);
