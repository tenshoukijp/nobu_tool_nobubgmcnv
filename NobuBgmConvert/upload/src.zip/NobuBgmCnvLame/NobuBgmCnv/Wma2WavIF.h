#pragma once

#include "wma2wav.h"

void CommandWma2Wav( char *szMySelf, char *szSrcFileName );

