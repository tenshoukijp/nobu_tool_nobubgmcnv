#pragma once

int OggToKvs(char *szSrc, char *szDst);
