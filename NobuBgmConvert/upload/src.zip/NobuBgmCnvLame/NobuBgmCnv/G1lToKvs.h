#pragma once


int G1lToKvs (char *szG1lFileName);
