#pragma once

int AtslwToKvs(char *szAtslwFileName );