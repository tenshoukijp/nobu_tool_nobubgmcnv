#pragma once;

void nobumain(void);