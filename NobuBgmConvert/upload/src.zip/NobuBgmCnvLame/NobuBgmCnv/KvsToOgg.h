#pragma once


int KvsToOgg(char *szKvsFileName);