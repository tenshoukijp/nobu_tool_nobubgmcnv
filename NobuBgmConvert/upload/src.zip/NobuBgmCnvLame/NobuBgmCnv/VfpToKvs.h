#pragma once

int VfpToKvs(char *szVpsFileName );